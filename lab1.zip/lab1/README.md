Товч танилцуулга

Python + Selenium ашиглан вэб дээрх логин, модал хаах, логоут үйлдлийг автоматжуулсан төсөл.

Ашигласан технологи
	•Python 3
	•Selenium WebDriver
	•webdriver_manager (ChromeDriver)

Хийсэн зүйлс
	•Login
	•close picture pop up
	•assert if profile picture exist
	•logout